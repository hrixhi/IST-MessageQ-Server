var zmq = require("zeromq");
var socket = zmq.socket("rep");

// Begin listening for connections on all IP addresses on port 9998.
socket.bind("tcp://*:9998", function (error) {
    if (error) {
        console.log("Failed to bind socket: " + error.message);
        process.exit(0);
    }
    else {
        console.log("Server listening on port 9998");
    }
});

// When a message is received from a client, send it to all client instances.
socket.on("message", function (message) {
    // Convert the message into a string and log to the console.
    console.log(JSON.parse(message));
    socket.send(message);
});

