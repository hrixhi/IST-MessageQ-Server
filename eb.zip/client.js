var zmq = require("zeromq");
var socket = zmq.socket("req");

// Add a callback for the event that is invoked when we receive a message.
socket.on("message", function (message) {
    console.log(JSON.parse(message))
});

// Connect to the server instance.
socket.connect('tcp://127.0.0.1:9998');

socket.send(JSON.stringify({name: 'hrishi'}))